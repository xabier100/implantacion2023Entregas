<?php
include 'funciones.inc';

$empleadosD=f_empleadosDepartamento(4);
var_dump($empleadosD);
