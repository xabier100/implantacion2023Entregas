<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "funciones.inc" ?>
</head>
<body>
<?php
$codDepartamento = $_GET["departamento"];
?>

<table>
    <thead>
    <tr>
        <th>
            Nombre empleado
        </th>
        <th>
            Puesto
        </th>
        <th>
            Fecha contratacion
        </th>
        <th>
            Nombre sucursal
        </th>
        <th>
            Direccion sucursal
        </th>
        <th>
            Ciudad sucursal
        </th>
    </tr>
    </thead>
    <tbody>
    <?php
    $empleadosDepart = f_empleadosDepartamento($codDepartamento);
    foreach ($empleadosDepart as $empleado) {
        echo("<tr>");
        echo("<td>");
        echo($empleado["Empleado"]);
        echo("</td>");
        echo("<td>");
        echo($empleado["Puesto"]);
        echo("</td>");
        echo("<td>");
        echo($empleado["FechaContratacion"]);
        echo("</td>");
        $idCursal = $empleado["ID_Sucursal"];
        echo("<td>");
        echo(f_nombreSucursal($idCursal));
        echo("</td>");
        echo("<td>");
        echo(f_direccionSucursal($idCursal));
        echo("</td>");
        echo("<td>");
        echo(f_ciudadSucursal($idCursal));
        echo("</td>");
        echo("</tr>");
    }
    ?>
    </tbody>
</table>

</body>
</html>